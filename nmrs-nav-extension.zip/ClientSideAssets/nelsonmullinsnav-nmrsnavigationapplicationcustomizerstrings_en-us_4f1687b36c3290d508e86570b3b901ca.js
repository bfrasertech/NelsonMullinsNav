define([], function() {
  return {
    "Title": "NmrsNavigationApplicationCustomizer"
  }
});